public enum CombatAction
{
    None,
    Idle,
    Stop,
    MoveToTarget,
    FaceTarget,
    UseSkill,
}
