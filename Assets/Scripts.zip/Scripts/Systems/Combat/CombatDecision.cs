using UnityEngine;

public struct CombatDecision
{
    public CombatAction Action;

    public DigimonSkill Skill;
    public CombatContext Context;

    public float Range;

    public static CombatDecision None => new CombatDecision { Action = CombatAction.None };

    public static CombatDecision Stop()
    {
        return new CombatDecision { Action = CombatAction.Stop };
    }

    public static CombatDecision Move(Vector3 destination, float range)
    {
        return new CombatDecision
        {
            Action = CombatAction.MoveToTarget,
            Context = new CombatContext(destination, Vector3.zero),
            Range = range,
        };
    }

    public static CombatDecision Face(Vector3 direction)
    {
        return new CombatDecision
        {
            Action = CombatAction.FaceTarget,
            Context = new CombatContext(Vector3.zero, direction),
        };
    }

    public static CombatDecision UseSkill(
        DigimonSkill skill,
        CombatContext context,
        float range = 0f
    )
    {
        if (skill == null)
        {
            Debug.LogWarning("⚠️ UseSkill recebeu skill NULL → fallback None");
            return None;
        }

        return new CombatDecision
        {
            Action = CombatAction.UseSkill,
            Skill = skill,
            Context = context,
            Range = range,
        };
    }

    public override string ToString()
    {
        return $"[Decision] Action={Action} Skill={(Skill ? Skill.name : "null")}";
    }
}
