using UnityEngine;

public class CombatDecisionExecutor
{
    private readonly DigimonMovement movement;
    private readonly DigimonAttack attack;

    public CombatDecisionExecutor(DigimonMovement movement, DigimonAttack attack)
    {
        this.movement = movement;
        this.attack = attack;
    }

    public void Execute(CombatDecision decision, Transform self)
    {
        if (decision.Action == CombatAction.None)
            return;

        switch (decision.Action)
        {
            case CombatAction.MoveToTarget:
                ExecuteMove(decision);
                break;

            case CombatAction.Stop:
                ExecuteStop();
                break;

            case CombatAction.FaceTarget:
                ExecuteFace(decision, self);
                break;

            case CombatAction.UseSkill:
                ExecuteUseSkill(decision, self);
                break;
        }
    }

    private void ExecuteMove(CombatDecision decision)
    {
        Vector3 destination = decision.Context.Origin;

        movement.SetDestination(destination);
    }

    private void ExecuteStop()
    {
        movement.StopMovement();
    }

    private void ExecuteFace(CombatDecision decision, Transform self)
    {
        Vector3 direction = decision.Context.Direction;

        if (direction.sqrMagnitude < 0.001f)
            return;

        RotateTowards(self, direction);
    }

    private void ExecuteUseSkill(CombatDecision decision, Transform self)
    {
        if (decision.Skill == null)
            return;

        Vector3 direction = decision.Context.Direction;

        if (direction.sqrMagnitude > 0.001f)
        {
            RotateTowards(self, direction);

            if (!IsFacingDirection(self, direction))
                return;
        }

        movement.StopMovement();

        attack.TryUseSkill(decision.Skill, decision.Context);
    }

    private void RotateTowards(Transform self, Vector3 direction)
    {
        direction.y = 0f;

        if (direction.sqrMagnitude < 0.001f)
            return;

        Quaternion targetRotation = Quaternion.LookRotation(direction);

        self.rotation = Quaternion.Slerp(self.rotation, targetRotation, Time.deltaTime * 10f);
    }

    private bool IsFacingDirection(Transform self, Vector3 direction, float threshold = 0.9f)
    {
        direction.y = 0f;
        direction.Normalize();

        float dot = Vector3.Dot(self.forward, direction);

        return dot >= threshold;
    }
}
