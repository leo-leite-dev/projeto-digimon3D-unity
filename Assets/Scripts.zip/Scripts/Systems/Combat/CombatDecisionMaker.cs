using UnityEngine;

public class CombatDecisionMaker
{
    private readonly DigimonAttack attack;

    public CombatDecisionMaker(DigimonAttack attack)
    {
        this.attack = attack;
    }

    public CombatDecision Decide(DigimonSkill skill, CombatContext context)
    {
        if (attack == null || skill == null)
            return CombatDecision.None;

        Transform target =
            context.SuggestedTarget != null ? context.SuggestedTarget.transform : null;

        var result = attack.EvaluateSkillUse(skill, context);

        switch (result)
        {
            case SkillUseCheckResult.Success:
                return CombatDecision.UseSkill(skill, context, skill.range);

            case SkillUseCheckResult.OutOfRange:
                if (target != null)
                {
                    Vector3 dir = (target.position - context.Origin).normalized;

                    return CombatDecision.Move(target.position, skill.range);
                }

                return CombatDecision.None;

            case SkillUseCheckResult.OnCooldown:
                return CombatDecision.None;

            case SkillUseCheckResult.AlreadyCasting:
                return CombatDecision.None;

            default:
                return CombatDecision.None;
        }
    }
}
