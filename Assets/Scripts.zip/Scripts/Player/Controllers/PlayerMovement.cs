using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerMovement : MonoBehaviour
{
    [Header("Config")]
    [SerializeField]
    private PlayerMovementConfig config;

    [Header("Debug / Systems")]
    [SerializeField]
    private int maxPositionHistory = 200;

    private CharacterController controller;
    private Animator animator;

    private PlayerControls input;
    private Transform cameraTransform;

    private Vector3 moveDirection;
    private Vector3 currentVelocity;
    private float verticalVelocity;

    private readonly Queue<Vector3> positionHistory = new();

    public bool IsMoving => currentVelocity.sqrMagnitude > 0.01f;
    public Vector3[] PositionHistory => positionHistory.ToArray();

    private RaycastHit groundHit;

    public void Setup(PlayerControls input, Transform cameraTransform)
    {
        this.input = input;
        this.cameraTransform = cameraTransform;

        if (this.input == null)
            Debug.LogError("[PlayerMovement] Input inválido no Setup.", this);

        if (this.cameraTransform == null)
            Debug.LogError("[PlayerMovement] Camera Transform inválido no Setup.", this);
    }

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        animator = GetComponentInChildren<Animator>();

        if (controller == null)
            Debug.LogError("[PlayerMovement] CharacterController não encontrado.", this);

        if (animator == null)
            Debug.LogError("[PlayerMovement] Animator não encontrado.", this);

        if (config == null)
            Debug.LogError("[PlayerMovement] Config não atribuída.", this);
    }

    void Update()
    {
        if (input == null || cameraTransform == null || config == null)
            return;

        ReadInput();
        HandleMovement();
        HandleRotation();
        UpdateAnimation();
        SavePositionHistory();
    }

    void ReadInput()
    {
        Vector2 inputVector = input.Movement.Move.ReadValue<Vector2>();

        float horizontal = inputVector.x;
        float vertical = inputVector.y;

        Vector3 cameraForward = cameraTransform.forward;
        Vector3 cameraRight = cameraTransform.right;

        cameraForward.y = 0f;
        cameraRight.y = 0f;

        cameraForward.Normalize();
        cameraRight.Normalize();

        moveDirection = cameraForward * vertical + cameraRight * horizontal;

        if (moveDirection.sqrMagnitude > 1f)
            moveDirection.Normalize();
    }

    void HandleMovement()
    {
        ApplyGravity();

        Vector3 groundNormal = Vector3.up;

        if (Physics.Raycast(transform.position, Vector3.down, out groundHit, 2f))
            groundNormal = groundHit.normal;

        Vector3 slopeDirection = Vector3.ProjectOnPlane(moveDirection, groundNormal).normalized;

        Vector3 targetVelocity = slopeDirection * config.speed;

        currentVelocity = Vector3.MoveTowards(
            currentVelocity,
            moveDirection.sqrMagnitude > 0.01f ? targetVelocity : Vector3.zero,
            (moveDirection.sqrMagnitude > 0.01f ? config.acceleration : config.deceleration)
                * Time.deltaTime
        );

        Vector3 velocity = currentVelocity;
        velocity.y = verticalVelocity;

        controller.Move(velocity * Time.deltaTime);
    }

    void ApplyGravity()
    {
        if (controller.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;

        verticalVelocity += config.gravity * Time.deltaTime;
    }

    void HandleRotation()
    {
        if (moveDirection.sqrMagnitude < 0.01f)
            return;

        Quaternion targetRotation = Quaternion.LookRotation(moveDirection);

        transform.rotation = Quaternion.Slerp(
            transform.rotation,
            targetRotation,
            config.rotationSpeed * Time.deltaTime
        );
    }

    void UpdateAnimation()
    {
        if (animator == null)
            return;

        float speedPercent = currentVelocity.magnitude / config.speed;

        animator.SetFloat("Speed", speedPercent, 0.1f, Time.deltaTime);
    }

    void SavePositionHistory()
    {
        if (currentVelocity.sqrMagnitude <= 0.01f)
            return;

        positionHistory.Enqueue(transform.position);

        if (positionHistory.Count > maxPositionHistory)
            positionHistory.Dequeue();
    }
}
