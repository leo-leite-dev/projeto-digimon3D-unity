using System.Collections.Generic;
using UnityEngine;

public class PlayerDigidex : ValidatedMonoBehaviour
{
    [Header("Digimons armazenados")]
    [SerializeField]
    private List<DigimonData> digidex = new();

    [Header("Digimon equipado")]
    [SerializeField]
    private DigimonData equippedDigimon;

    private DigimonSpawnService spawnService;
    private PlayerCombatController combatController;

    private Transform spawnPoint;
    private Transform followPoint;

    private GameObject currentDigimonObject;

    private bool isInitialized;

    public void Initialize(
        DigimonSpawnService spawnService,
        PlayerCombatController combatController,
        Transform spawnPoint,
        Transform followPoint
    )
    {
        this.spawnService = spawnService;
        this.combatController = combatController;
        this.spawnPoint = spawnPoint;
        this.followPoint = followPoint;

        isInitialized = true;

        if (equippedDigimon != null)
            SpawnEquippedDigimon();
    }

    public void CaptureDigimon(DigimonData data)
    {
        if (data == null)
            return;

        if (!digidex.Contains(data))
            digidex.Add(data);
    }

    public void EquipDigimon(DigimonData data)
    {
        if (data == null || !digidex.Contains(data))
            return;

        equippedDigimon = data;

        if (isInitialized)
            SpawnEquippedDigimon();
    }

    private void SpawnEquippedDigimon()
    {
        if (!isInitialized || spawnService == null || equippedDigimon == null)
        {
            Debug.LogError("❌ Digidex não inicializado corretamente");
            return;
        }

        DespawnCurrentDigimon();

        var go = spawnService.Spawn(equippedDigimon, spawnPoint.position, spawnPoint.rotation);

        if (go == null)
            return;

        var follow = go.GetComponent<DigimonFollow>();

        if (follow == null)
        {
            Debug.LogError("❌ DigimonFollow não encontrado", go);
            Destroy(go);
            return;
        }

        follow.Setup(equippedDigimon);

        DigimonFollowComposer.Compose(go);

        follow.Initialize(transform, followPoint);

        currentDigimonObject = go;

        combatController.SetDigimon(follow);
    }

    private void DespawnCurrentDigimon()
    {
        if (currentDigimonObject != null)
            Destroy(currentDigimonObject);

        currentDigimonObject = null;
    }

    public DigimonData GetEquipped()
    {
        return equippedDigimon;
    }
}
