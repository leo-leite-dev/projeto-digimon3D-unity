using UnityEngine;

public class PlayerCombatController : ValidatedMonoBehaviour
{
    private DigimonFollow currentDigimon;
    public DigimonFollow CurrentDigimon => currentDigimon;

    public void Initialize() { }

    public void UseSkill(DigimonSkill skill, CombatContext context)
    {
        if (skill == null)
        {
            Debug.LogWarning("[PlayerCombatController] Skill inválida");
            return;
        }

        if (currentDigimon == null)
        {
            Debug.LogWarning("[PlayerCombatController] Nenhum Digimon ativo");
            return;
        }

        currentDigimon.RequestSkill(skill, context);
    }

    public void SetDigimon(DigimonFollow digimon)
    {
        if (digimon == null)
        {
            Debug.LogWarning("[PlayerCombatController] Tentando setar Digimon nulo");
            return;
        }

        currentDigimon = digimon;

        Debug.Log($"[PlayerCombatController] ✅ Digimon ativo: {digimon.name}");
    }

    public void ClearDigimon()
    {
        currentDigimon = null;
    }
}
