using UnityEngine;

public class PlayerComposer : MonoBehaviour
{
    [Header("References")]
    [SerializeField]
    private PlayerReferences references;

    [Header("Gameplay")]
    [SerializeField]
    private PlayerDigidex digidex;

    [SerializeField]
    private PlayerInputController inputController;

    [SerializeField]
    private HotbarController hotbar;

    [SerializeField]
    private InventoryController inventory;

    [SerializeField]
    private GameObject digimonBasePrefab;

    private PlayerControls input;

    private void Awake()
    {
        input = new PlayerControls();

        Compose(references);
    }

    private void OnEnable()
    {
        input.Enable();
    }

    private void OnDisable()
    {
        input.Disable();
    }

    public void Compose(PlayerReferences refs)
    {
        if (!ValidateAll(refs))
            return;

        SetupInput();

        SetupMovement(refs);
        SetupCombat(refs);

        var spawnService = new DigimonSpawnService(digimonBasePrefab);

        SetupDigidex(refs, spawnService);
        SetupHotbar(refs);

        Debug.Log("[PlayerComposer] ✅ Player COMPOSED com sucesso");
    }

    private void SetupInput()
    {
        inputController.Initialize(input);
    }

    private void SetupMovement(PlayerReferences refs)
    {
        refs.Movement.Setup(input, refs.CameraTransform);
    }

    private void SetupCombat(PlayerReferences refs)
    {
        refs.Combat.Initialize();
    }

    private void SetupHotbar(PlayerReferences refs)
    {
        hotbar.Initialize(refs.Combat, inventory);
    }

    private void SetupDigidex(PlayerReferences refs, DigimonSpawnService spawnService)
    {
        digidex.Initialize(spawnService, refs.Combat, refs.SpawnPoint, refs.FollowPoint);
    }

    private bool ValidateAll(PlayerReferences refs)
    {
        bool valid = true;

        if (refs == null || !refs.IsValid())
        {
            Debug.LogError("❌ PlayerReferences inválido", this);
            valid = false;
        }

        if (inputController == null)
        {
            Debug.LogError("❌ PlayerInputController não atribuído", this);
            valid = false;
        }

        if (digidex == null)
        {
            Debug.LogError("❌ PlayerDigidex não atribuído", this);
            valid = false;
        }

        if (hotbar == null)
        {
            Debug.LogError("❌ HotbarController não atribuído", this);
            valid = false;
        }

        if (inventory == null)
        {
            Debug.LogError("❌ InventoryController não atribuído", this);
            valid = false;
        }

        return valid;
    }
}
