using UnityEngine;

public class PlayerReferences : MonoBehaviour
{
    [Header("=== Gameplay Components ===")]
    [SerializeField]
    private PlayerMovement movement;

    [SerializeField]
    private PlayerCombatController combat;

    [Header("=== Scene References ===")]
    [SerializeField]
    private Transform cameraTransform;

    [SerializeField]
    private Transform spawnPoint;

    [SerializeField]
    private Transform followPoint;

    public PlayerMovement Movement => movement;
    public PlayerCombatController Combat => combat;

    public Transform CameraTransform => cameraTransform;
    public Transform SpawnPoint => spawnPoint;
    public Transform FollowPoint => followPoint;

    public bool IsValid()
    {
        bool valid = true;

        void Check(Object obj, string name)
        {
            if (obj == null)
            {
                Debug.LogError($"❌ PlayerReferences: {name} missing", this);
                valid = false;
            }
        }

        Check(movement, nameof(movement));
        Check(combat, nameof(combat));
        Check(cameraTransform, nameof(cameraTransform));
        Check(spawnPoint, nameof(spawnPoint));
        Check(followPoint, nameof(followPoint));

        return valid;
    }

#if UNITY_EDITOR
    [ContextMenu("Validate References")]
    private void ValidateInEditor()
    {
        IsValid();
    }
#endif
}
