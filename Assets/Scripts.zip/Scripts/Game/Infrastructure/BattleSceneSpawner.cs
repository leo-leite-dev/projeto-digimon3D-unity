using UnityEngine;

public class BattleSceneSpawner : MonoBehaviour
{
    [Header("Spawn Points")]
    [SerializeField]
    private Transform playerSpawnPoint;

    [SerializeField]
    private Transform playerDigimonSpawnPoint;

    [SerializeField]
    private Transform enemySpawnPoint;

    public Transform PlayerTransform { get; private set; }
    public Transform PlayerDigimonTransform { get; private set; }
    public Transform EnemyTransform { get; private set; }

    private void Start()
    {
        SpawnPlayerWithDigimon();
        SpawnEnemy();
    }

    private void SpawnPlayerWithDigimon()
    {
        var tamer = CombatContextData.TamerStats;
        var digimonData = CombatContextData.PlayerDigimon;

        if (tamer == null || digimonData == null)
        {
            Debug.LogError("❌ Player data inválido");
            return;
        }

        if (tamer.prefab == null)
        {
            Debug.LogError($"❌ Tamer {tamer.tamerName} não possui prefab");
            return;
        }

        var playerGO = Instantiate(
            tamer.prefab,
            playerSpawnPoint.position,
            playerSpawnPoint.rotation
        );

        PlayerTransform = playerGO.transform;

        var stats = playerGO.GetComponent<PlayerStatsController>();
        if (stats != null)
        {
            // stats.SetConfig(tamer);
        }

        if (digimonData.modelPrefab == null)
        {
            Debug.LogError($"❌ Digimon {digimonData.digimonName} não possui prefab");
            return;
        }

        var digimonGO = DigimonFactory.Create(
            digimonData.modelPrefab,
            digimonData,
            playerDigimonSpawnPoint.position
        );

        PlayerDigimonTransform = digimonGO.transform;

        DigimonFollowComposer.Compose(digimonGO);

        Debug.Log($"👤 Player + Digimon ({digimonData.digimonName}) spawnados");
    }

    private void SpawnEnemy()
    {
        var enemyData = CombatContextData.SelectedEnemy;

        if (enemyData == null)
        {
            Debug.LogError("❌ Nenhum inimigo");
            return;
        }

        if (enemyData.modelPrefab == null)
        {
            Debug.LogError($"❌ Enemy {enemyData.digimonName} sem prefab");
            return;
        }

        var enemyGO = DigimonFactory.Create(
            enemyData.modelPrefab,
            enemyData,
            enemySpawnPoint.position
        );

        EnemyTransform = enemyGO.transform;

        DigimonEnemyComposer.Compose(enemyGO);

        Debug.Log($"👾 Enemy: {enemyData.digimonName}");
    }
}
