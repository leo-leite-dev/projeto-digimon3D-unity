using UnityEngine;

public class BattleSceneComposer : MonoBehaviour
{
    [SerializeField]
    private BattleSceneSpawner spawner;

    [SerializeField]
    private CombatCameraController cameraController;

    private void Start()
    {
        cameraController.Initialize(spawner.PlayerDigimonTransform, spawner.EnemyTransform);
    }
}
