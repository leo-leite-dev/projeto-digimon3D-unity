using UnityEngine;

public class CombatCameraController : MonoBehaviour
{
    [Header("Settings")]
    [SerializeField]
    private float distance = 10f;

    [SerializeField]
    private float height = 3f;

    [SerializeField]
    private float smoothSpeed = 5f;

    private Transform player;
    private Transform enemy;

    public void Initialize(Transform player, Transform enemy)
    {
        this.player = player;
        this.enemy = enemy;
    }

    private void LateUpdate()
    {
        if (player == null || enemy == null)
            return;

        UpdateCamera();
    }

    private void UpdateCamera()
    {
        Vector3 p1 = player.position;
        Vector3 p2 = enemy.position;

        Vector3 center = (p1 + p2) * 0.5f;

        Vector3 direction = (p2 - p1).normalized;

        Vector3 side = Vector3.Cross(direction, Vector3.up);

        Vector3 targetPosition = center + side * distance + Vector3.up * height;

        transform.position = Vector3.Lerp(
            transform.position,
            targetPosition,
            Time.deltaTime * smoothSpeed
        );

        transform.LookAt(center);
    }
}
