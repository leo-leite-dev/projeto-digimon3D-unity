using UnityEngine;

public class DigimonFollow : Digimon
{
    [Header("References")]
    public Transform player;
    public Transform followPoint;

    [SerializeField]
    private DigimonMovement movement;

    [SerializeField]
    private DigimonAttack attack;

    private Animator animator;

    [Header("Follow")]
    [SerializeField]
    private float repathDistance = 0.25f;

    private Vector3 lastFollowPosition;

    private DigimonSkill pendingSkill;
    private GameObject requestedSkillTarget;
    private bool isTryingToUseSkill;

    protected override void Validate()
    {
        base.Validate();

        if (movement == null)
            movement = GetComponent<DigimonMovement>();

        if (attack == null)
            attack = GetComponent<DigimonAttack>();
    }

    protected override void Awake()
    {
        base.Awake();

        movement ??= GetComponent<DigimonMovement>();
        attack ??= GetComponent<DigimonAttack>();

        if (movement == null)
            Debug.LogError($"{nameof(DigimonFollow)}: DigimonMovement não encontrado.", this);

        if (attack == null)
            Debug.LogError($"{nameof(DigimonFollow)}: DigimonAttack não encontrado.", this);
    }

    public override void Setup(DigimonData digimonData)
    {
        base.Setup(digimonData);

        animator = GetComponentInChildren<Animator>(true);
    }

    public void Initialize(Transform playerRef, Transform followPointRef)
    {
        player = playerRef;
        followPoint = followPointRef;

        if (followPoint != null)
            lastFollowPosition = followPoint.position;
    }

    private void Update()
    {
        if (Data == null)
            return;

        if (player == null || followPoint == null)
            return;

        if (isTryingToUseSkill)
            HandlePendingSkill();
        else
            FollowPlayer();

        UpdateAnimation();
    }

    private void FollowPlayer()
    {
        if (movement == null)
            return;

        Vector3 targetPosition = followPoint.position;
        float sqrDistance = (targetPosition - lastFollowPosition).sqrMagnitude;

        if (sqrDistance >= repathDistance * repathDistance)
        {
            movement.SetDestination(targetPosition);
            lastFollowPosition = targetPosition;
        }
    }

    private void UpdateAnimation()
    {
        if (animator == null || movement == null)
            return;

        animator.SetFloat("Speed", movement.Velocity.magnitude);
    }

    public void RequestSkillUse(DigimonSkill skill, GameObject target)
    {
        if (skill == null || target == null)
            return;

        pendingSkill = skill;
        requestedSkillTarget = target;
        isTryingToUseSkill = true;
    }

    private void HandlePendingSkill()
    {
        if (pendingSkill == null || requestedSkillTarget == null)
        {
            ClearPendingSkill();
            return;
        }

        if (attack == null || movement == null)
        {
            ClearPendingSkill();
            return;
        }

        if (!IsPendingTargetStillValid())
        {
            ClearPendingSkill();
            return;
        }

        SkillUseCheckResult result = attack.EvaluateSkillUse(pendingSkill, requestedSkillTarget);

        switch (result)
        {
            case SkillUseCheckResult.Success:
                movement.StopMovement();
                attack.TryUseSkill(pendingSkill, requestedSkillTarget);
                ClearPendingSkill();
                break;

            case SkillUseCheckResult.OutOfRange:
                movement.MoveToSkillRange(requestedSkillTarget.transform, pendingSkill.range);
                break;

            case SkillUseCheckResult.OnCooldown:
            case SkillUseCheckResult.AlreadyCasting:
                movement.StopMovement();
                break;

            default:
                ClearPendingSkill();
                break;
        }
    }

    private bool IsPendingTargetStillValid()
    {
        return requestedSkillTarget != null && requestedSkillTarget.activeInHierarchy;
    }

    private void ClearPendingSkill()
    {
        pendingSkill = null;
        requestedSkillTarget = null;
        isTryingToUseSkill = false;

        if (followPoint != null)
            lastFollowPosition = followPoint.position;
    }
}
