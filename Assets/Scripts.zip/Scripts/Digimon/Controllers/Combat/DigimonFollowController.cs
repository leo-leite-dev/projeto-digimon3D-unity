using UnityEngine;

public class DigimonFollowController : MonoBehaviour
{
    private DigimonAttack attack;
    private CombatDecisionMaker decisionMaker;
    private DigimonAnimator digimonAnimator;

    private DigimonSkill pendingSkill;
    private CombatContext pendingContext;
    private bool hasPendingSkill;

    public void Inject(DigimonAttack atk)
    {
        if (atk == null)
        {
            Debug.LogError("❌ Attack não injetado no FollowController", this);
            return;
        }

        attack = atk;

        decisionMaker = new CombatDecisionMaker(atk);
    }

    public void SetAnimator(DigimonAnimator animator)
    {
        if (animator == null)
        {
            Debug.LogError("❌ DigimonAnimator não injetado no FollowController", this);
            return;
        }

        digimonAnimator = animator;
    }

    public void RequestSkill(DigimonSkill skill, CombatContext context)
    {
        if (skill == null)
            return;

        pendingSkill = skill;
        pendingContext = context;
        hasPendingSkill = true;
    }

    public CombatDecision Tick()
    {
        if (attack == null || decisionMaker == null)
            return CombatDecision.None;

        if (!hasPendingSkill)
            return CombatDecision.None;

        hasPendingSkill = false;

        var decision = decisionMaker.Decide(pendingSkill, pendingContext);

        pendingSkill = null;

        return decision;
    }

    public void BindHitReceiver(DigimonHitReceiver hitReceiver)
    {
        if (hitReceiver == null)
            return;

        hitReceiver.OnHit -= HandleHit;
        hitReceiver.OnHit += HandleHit;
    }

    private void HandleHit(Transform attacker)
    {
        if (attacker == null)
            return;

        Debug.Log($"🔥 FOLLOW tomou hit de: {attacker.name}");

    }

    private void ClearCombat()
    {
        pendingSkill = null;
        hasPendingSkill = false;
    }

    public bool IsInCombat => hasPendingSkill;
}
