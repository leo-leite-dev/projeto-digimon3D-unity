using UnityEngine;

public class DigimonMovementAnimator : MonoBehaviour
{
    [SerializeField]
    private DigimonMovement movement;

    [SerializeField]
    private DigimonAnimator animator;

    void Update()
    {
        if (movement == null || animator == null)
            return;

        animator.SetSpeed(movement.Velocity.magnitude);
    }
}
