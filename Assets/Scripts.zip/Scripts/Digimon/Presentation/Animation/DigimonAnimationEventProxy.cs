using UnityEngine;

public class DigimonAnimationEventProxy : MonoBehaviour
{
    private DigimonAttack attack;

    public void Initialize(DigimonAttack attack)
    {
        this.attack = attack;
    }

    public void AnimationEvent_SpawnEffect()
    {
        attack?.OnSpawnEffect();
    }

    public void AnimationEvent_ApplyHit()
    {
        attack?.OnApplyHit();
    }

    public void AnimationEvent_FinishSkill()
    {
        attack?.OnFinishSkill();
    }

    public void AnimationEvent_OnActivateProjectile()
    {
        attack?.OnActivateProjectile();
    }
}
