using UnityEngine;

public static class DigimonVisualBuilder
{
    public static void Build(Digimon digimon)
    {
        if (digimon == null)
        {
            Debug.LogError("❌ Digimon é null no VisualBuilder");
            return;
        }

        if (digimon.Data == null)
        {
            Debug.LogError($"❌ Digimon sem Data: {digimon.name}", digimon);
            return;
        }

        var references = digimon.GetComponent<DigimonReferences>();

        if (references == null)
        {
            Debug.LogError($"❌ DigimonReferences não encontrado em {digimon.name}", digimon);
            return;
        }

        Transform modelRoot = GetOrCreateModelRoot(references);

        Clear(modelRoot);

        GameObject model = SpawnModel(digimon, modelRoot);

        if (model == null)
            return;

        ResolveReferences(references);

        Compose(digimon.gameObject);
    }

    static Transform GetOrCreateModelRoot(DigimonReferences references)
    {
        if (references.ModelRoot != null)
            return references.ModelRoot;

        Transform found = references.transform.Find("ModelRoot");

        if (found != null)
            return found;

        GameObject go = new GameObject("ModelRoot");
        go.transform.SetParent(references.transform);
        go.transform.localPosition = Vector3.zero;
        go.transform.localRotation = Quaternion.identity;

        return go.transform;
    }

    static void Clear(Transform root)
    {
        for (int i = root.childCount - 1; i >= 0; i--)
        {
            Object.Destroy(root.GetChild(i).gameObject);
        }
    }

    static GameObject SpawnModel(Digimon digimon, Transform root)
    {
        if (digimon.Data.modelPrefab == null)
        {
            Debug.LogError($"❌ {digimon.name} sem prefab no DigimonData", digimon);
            return null;
        }

        GameObject model = Object.Instantiate(digimon.Data.modelPrefab, root);

        model.transform.localPosition = Vector3.zero;
        model.transform.localRotation = Quaternion.identity;
        model.transform.localScale = Vector3.one;

        return model;
    }

    static void ResolveReferences(DigimonReferences references)
    {
        DigimonVisualReferencesResolver.Refresh(references);
    }


    static void Compose(GameObject digimonGO)
    {
        DigimonComposer.Compose(digimonGO);
    }
}
