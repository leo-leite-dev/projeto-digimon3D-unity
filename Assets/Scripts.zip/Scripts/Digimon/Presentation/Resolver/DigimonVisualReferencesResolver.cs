using UnityEngine;

public static class DigimonVisualReferencesResolver
{
    public static void Refresh(DigimonReferences references)
    {
        if (references == null)
        {
            Debug.LogError("❌ DigimonReferences é null.");
            return;
        }

        Transform modelRoot = ResolveModelRoot(references);

        if (modelRoot == null)
        {
            Debug.LogError($"❌ ModelRoot não encontrado em {references.name}", references);
            return;
        }

        DigimonModelBinder binder = modelRoot.GetComponentInChildren<DigimonModelBinder>(true);

        Animator animator;
        Transform firePoint;
        DigimonAnimator digimonAnimator;

        if (binder != null)
        {
            animator = binder.Animator;
            firePoint = binder.FirePoint;
            digimonAnimator = binder.DigimonAnimator;
        }
        else
        {
            animator = modelRoot.GetComponentInChildren<Animator>(true);
            digimonAnimator = modelRoot.GetComponentInChildren<DigimonAnimator>(true);
            firePoint = FindChildRecursive(modelRoot, "FirePoint");

            Debug.LogWarning(
                $"⚠️ {references.name} sem DigimonModelBinder. Usando fallback automático.",
                references
            );
        }

        if (animator == null)
            Debug.LogWarning($"⚠️ Animator não encontrado em {references.name}", references);

        if (firePoint == null)
            Debug.LogWarning($"⚠️ FirePoint não encontrado em {references.name}", references);

        if (digimonAnimator == null)
            Debug.LogWarning($"⚠️ DigimonAnimator não encontrado em {references.name}", references);

        references.SetVisualReferences(modelRoot, animator, firePoint, digimonAnimator);
    }

    static Transform ResolveModelRoot(DigimonReferences references)
    {
        if (references.ModelRoot != null)
            return references.ModelRoot;

        Transform found = FindChildRecursive(references.transform, "ModelRoot");

        if (found != null)
            return found;

        return references.transform;
    }

    static Transform FindChildRecursive(Transform parent, string name)
    {
        foreach (Transform child in parent)
        {
            if (child.name == name)
                return child;

            Transform result = FindChildRecursive(child, name);

            if (result != null)
                return result;
        }

        return null;
    }
}
