using UnityEngine;

public class DigimonModelBinder : MonoBehaviour
{
    [SerializeField]
    private Animator animator;

    [SerializeField]
    private Transform firePoint;

    [SerializeField]
    private DigimonAnimator digimonAnimator;

    public Animator Animator => animator;
    public Transform FirePoint => firePoint;
    public DigimonAnimator DigimonAnimator => digimonAnimator;

#if UNITY_EDITOR
    void OnValidate()
    {
        if (animator == null)
            Debug.LogError($"{name}: Animator não definido no DigimonModelBinder.", this);

        if (firePoint == null)
            Debug.LogError($"{name}: FirePoint não definido no DigimonModelBinder.", this);

        if (digimonAnimator == null)
            Debug.LogError($"{name}: DigimonAnimator não definido no DigimonModelBinder.", this);
    }
#endif
}
