using UnityEngine;
using UnityEngine.AI;

public class DigimonSpawnService
{
    private readonly GameObject basePrefab;

    public DigimonSpawnService(GameObject basePrefab)
    {
        this.basePrefab = basePrefab;
    }

    public GameObject Spawn(DigimonData data, Vector3 position, Quaternion rotation)
    {
        var go = DigimonFactory.Create(basePrefab, data, position, rotation);

        if (go == null)
            return null;

        var agent = go.GetComponent<NavMeshAgent>();
        if (agent != null)
            NavMeshUtility.WarpAgentToValidPosition(agent, position);

        return go;
    }
}
