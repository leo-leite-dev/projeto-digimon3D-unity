using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public WanderArea wanderArea;

    [Header("Enemy Types")]
    public List<DigimonData> enemyTypes;

    [Header("Enemy Base Prefab")]
    public GameObject enemyBasePrefab;

    public int maxEnemies = 3;
    public float respawnTime = 5f;

    public System.Action<DigimonEnemy> OnEnemySpawned;

    private List<GameObject> aliveEnemies = new List<GameObject>();

    void Awake()
    {
        if (wanderArea == null)
            wanderArea = GetComponent<WanderArea>();
    }

    void Start()
    {
        SpawnInitialEnemies();
    }

    void SpawnInitialEnemies()
    {
        for (int i = 0; i < maxEnemies; i++)
        {
            SpawnEnemy();
        }
    }

    void SpawnEnemy()
    {
        if (!CanSpawn())
            return;

        DigimonData data = GetRandomEnemyData();

        if (!SpawnPositionResolver.TryGetValidPosition(wanderArea, out Vector3 position))
            return;

        GameObject enemyGO = DigimonFactory.Create(enemyBasePrefab, data, position);

        if (enemyGO == null)
            return;

        aliveEnemies.Add(enemyGO);

        EnemyInitializer.Initialize(enemyGO, wanderArea);

        var enemy = enemyGO.GetComponent<DigimonEnemy>();
        if (enemy != null)
            OnEnemySpawned?.Invoke(enemy);
    }

    bool CanSpawn()
    {
        return enemyTypes != null && enemyTypes.Count > 0 && wanderArea != null;
    }

    DigimonData GetRandomEnemyData()
    {
        return enemyTypes[Random.Range(0, enemyTypes.Count)];
    }

    public void NotifyEnemyDeath(GameObject enemy)
    {
        if (aliveEnemies.Contains(enemy))
            aliveEnemies.Remove(enemy);

        Invoke(nameof(SpawnEnemy), respawnTime);
    }
}
