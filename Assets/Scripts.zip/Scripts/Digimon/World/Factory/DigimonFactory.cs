using UnityEngine;

public static class DigimonFactory
{
    public static GameObject Create(GameObject prefab, DigimonData data, Vector3 position)
    {
        GameObject go = Object.Instantiate(prefab, position, Quaternion.identity);

        var references = go.GetComponent<DigimonReferences>();

        if (references == null)
        {
            Debug.LogError("❌ Sem DigimonReferences", go);
            Object.Destroy(go);
            return null;
        }

        DigimonCoreReferencesResolver.Refresh(references);
        DigimonVisualReferencesResolver.Refresh(references);

        var digimon = go.GetComponent<Digimon>();
        digimon.Setup(data);

        DigimonComposer.Compose(go);

        return go;
    }
}
