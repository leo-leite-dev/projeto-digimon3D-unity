using UnityEngine;

public static class DigimonFactory
{
    public static GameObject Create(
        GameObject basePrefab,
        DigimonData data,
        Vector3 position,
        Quaternion rotation
    )
    {
        if (basePrefab == null)
        {
            Debug.LogError("❌ BasePrefab nulo");
            return null;
        }

        // 👇 COLOCA AQUI
        Debug.Log($"DATA: {data?.name} | MODEL: {data?.modelPrefab}");

        if (data == null || data.modelPrefab == null)
        {
            Debug.LogError("❌ DigimonData inválido");
            return null;
        }

        var go = Object.Instantiate(basePrefab, position, rotation);
        go.name = data.digimonName;

        var references = go.GetComponent<DigimonReferences>();

        if (references == null)
        {
            Debug.LogError("❌ DigimonReferences não encontrado", go);
            Object.Destroy(go);
            return null;
        }

        if (references.ModelRoot == null)
        {
            Debug.LogError("❌ ModelRoot não definido no DigimonReferences", go);
            Object.Destroy(go);
            return null;
        }

        var model = Object.Instantiate(data.modelPrefab, references.ModelRoot);

        references.BindRuntime(model);

        return go;
    }

    // 🔥 overload opcional (qualidade de vida)
    public static GameObject Create(GameObject basePrefab, DigimonData data, Vector3 position)
    {
        return Create(basePrefab, data, position, Quaternion.identity);
    }
}
