using UnityEngine;

public class HotbarController : MonoBehaviour
{
    [Header("Slots")]
    [SerializeField]
    private HotbarSlot[] slots = new HotbarSlot[8];

    private PlayerCombatController combatController;
    private InventoryController inventoryController;

    public void Initialize(
        PlayerCombatController combatController,
        InventoryController inventoryController
    )
    {
        this.combatController = combatController;
        this.inventoryController = inventoryController;

        ValidateSlots();
    }

    private void ValidateSlots()
    {
        if (slots == null || slots.Length == 0)
            slots = new HotbarSlot[8];

        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i] == null)
                slots[i] = new HotbarSlot();
        }
    }

    public void UseSlot(int index, CombatContext context)
    {
        if (index < 0 || index >= slots.Length)
        {
            Debug.LogWarning("[Hotbar] Slot inválido");
            return;
        }

        var slot = slots[index];

        switch (slot.type)
        {
            case SlotType.Skill:
                UseDigimonSkill(index, context);
                break;

            case SlotType.Item:
                UseItem(slot);
                break;

            default:
                Debug.LogWarning("[Hotbar] Tipo de slot desconhecido");
                break;
        }
    }

    private void UseDigimonSkill(int index, CombatContext context)
    {
        if (combatController == null)
        {
            Debug.LogError("[Hotbar] CombatController não injetado");
            return;
        }

        var currentDigimon = combatController.CurrentDigimon;

        if (currentDigimon == null || !currentDigimon.IsInitialized)
        {
            Debug.LogWarning("[Hotbar] Digimon inválido");
            return;
        }

        var skills = currentDigimon.Skills;

        if (skills == null || skills.Count == 0)
        {
            Debug.LogWarning("[Hotbar] Digimon sem skills");
            return;
        }

        if (index >= skills.Count)
        {
            Debug.LogWarning("[Hotbar] Slot sem skill correspondente");
            return;
        }

        var skill = skills[index];

        if (skill == null)
        {
            Debug.LogWarning("[Hotbar] Skill nula");
            return;
        }

        combatController.UseSkill(skill, context);
    }

    private void UseItem(HotbarSlot slot)
    {
        if (inventoryController == null)
        {
            Debug.LogError("[Hotbar] InventoryController não injetado");
            return;
        }

        if (slot.item == null)
        {
            Debug.LogWarning("[Hotbar] Item nulo");
            return;
        }

        inventoryController.UseItem(slot.item);
    }

    public int SlotCount => slots.Length;
}
