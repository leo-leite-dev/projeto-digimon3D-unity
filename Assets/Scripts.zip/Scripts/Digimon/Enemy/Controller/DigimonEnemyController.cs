using UnityEngine;

public class DigimonEnemyController : MonoBehaviour
{
    private EnemyWander wander;

    // FUTURO
    // private EnemyChase chase;
    // private EnemyAttack attack;

    private MonoBehaviour currentBehaviour;

    private void Awake()
    {
        wander = GetComponent<EnemyWander>();

        // FUTURO
        // chase = GetComponent<EnemyChase>();
        // attack = GetComponent<EnemyAttack>();
    }

    private void Start()
    {
        ActivateInitialState();
    }

    // =========================
    // INITIAL STATE
    // =========================
    void ActivateInitialState()
    {
        SwitchTo(wander);
    }

    // =========================
    // STATE CONTROL
    // =========================
    void SwitchTo(MonoBehaviour next)
    {
        if (currentBehaviour == next)
            return;

        DeactivateCurrent();

        currentBehaviour = next;

        ActivateCurrent();
    }

    void ActivateCurrent()
    {
        if (currentBehaviour == null)
            return;

        if (currentBehaviour is EnemyWander w)
            w.Activate();

        // FUTURO
        // if (currentBehaviour is EnemyChase c) c.Activate();
        // if (currentBehaviour is EnemyAttack a) a.Activate();
    }

    void DeactivateCurrent()
    {
        if (currentBehaviour == null)
            return;

        if (currentBehaviour is EnemyWander w)
            w.Deactivate();

        // FUTURO
        // if (currentBehaviour is EnemyChase c) c.Deactivate();
        // if (currentBehaviour is EnemyAttack a) a.Deactivate();
    }

    // =========================
    // FUTURO (DECISÃO)
    // =========================
    /*
    void Update()
    {
        if (HasTargetInRange())
            SwitchTo(chase);
        else
            SwitchTo(wander);
    }

    bool HasTargetInRange()
    {
        return false;
    }
    */
}
