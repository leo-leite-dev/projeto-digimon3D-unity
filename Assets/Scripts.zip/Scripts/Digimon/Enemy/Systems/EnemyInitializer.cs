using UnityEngine;

public static class EnemyInitializer
{
    public static void Initialize(GameObject enemyGO, WanderArea wanderArea)
    {
        var references = enemyGO.GetComponent<DigimonReferences>();

        if (references == null)
        {
            Debug.LogError("❌ DigimonReferences não encontrado", enemyGO);
            return;
        }

        // 🔹 Comportamentos
        InitializeWander(enemyGO, references, wanderArea);

        // 🔹 FUTURO (plugável)
        // InitializeChase(enemyGO, references);
        // InitializeAttack(enemyGO, references);
    }

    static void InitializeWander(
        GameObject enemyGO,
        DigimonReferences references,
        WanderArea wanderArea
    )
    {
        var wander = enemyGO.GetComponent<EnemyWander>();

        if (wander == null)
        {
            Debug.LogWarning("⚠️ Enemy sem EnemyWander", enemyGO);
            return;
        }

        if (references.Movement == null)
        {
            Debug.LogError("❌ Movement não resolvido antes do Wander", enemyGO);
            return;
        }

        var context = new WanderContext(
            wanderArea,
            references.Movement,
            references.DigimonAnimator
        );

        wander.Initialize(context);
    }
}
