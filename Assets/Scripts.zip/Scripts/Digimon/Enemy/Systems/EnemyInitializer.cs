using UnityEngine;

public static class EnemyInitializer
{
    public static void Initialize(GameObject enemyGO, WanderArea wanderArea, Transform player)
    {
        var references = enemyGO.GetComponent<DigimonReferences>();

        if (references == null)
        {
            Debug.LogError("❌ DigimonReferences não encontrado", enemyGO);
            return;
        }

        var enemy = enemyGO.GetComponent<DigimonEnemy>();

        if (enemy != null)
        {
            if (player != null)
                enemy.InjectTarget(player);
            else
                Debug.LogWarning("⚠️ Player null ao injetar target", enemyGO);
        }

        InitializeWander(enemyGO, references, wanderArea);
    }

    static void InitializeWander(
        GameObject enemyGO,
        DigimonReferences references,
        WanderArea wanderArea
    )
    {
        var wander = enemyGO.GetComponent<EnemyWander>();

        if (wander == null)
        {
            Debug.LogWarning("⚠️ Enemy sem EnemyWander", enemyGO);
            return;
        }

        if (references.Movement == null)
        {
            Debug.LogError("❌ Movement não resolvido antes do Wander", enemyGO);
            return;
        }

        var sampler = new NavMeshWanderPositionSampler(wanderArea, 5f);

        var context = new WanderContext(references.Movement, sampler);

        wander.Initialize(context);
    }
}
