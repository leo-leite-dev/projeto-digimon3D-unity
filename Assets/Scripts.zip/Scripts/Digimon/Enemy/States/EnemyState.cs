public enum EnemyState
{
    Idle,
    Patrol,
    Alert,
    InCombat,
}
