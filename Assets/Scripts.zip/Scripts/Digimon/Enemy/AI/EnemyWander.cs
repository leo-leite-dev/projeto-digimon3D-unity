using UnityEngine;
using UnityEngine.AI;

public class EnemyWander : MonoBehaviour, IContextInitializable<WanderContext>
{
    private WanderArea wanderArea;
    private DigimonMovement movement;

    [Header("Wander")]
    [SerializeField]
    private float waitTime = 2f;

    [SerializeField]
    private float samplePositionRadius = 5f;

    private float waitTimer;
    private bool active;

    public void Initialize(WanderContext context)
    {
        wanderArea = context.WanderArea;
        movement = context.Movement;

        if (movement == null)
        {
            Debug.LogError("❌ EnemyWander sem Movement", this);
            return;
        }

        active = false;
    }

    public void Activate()
    {
        active = true;
        waitTimer = waitTime;

        ChooseNewTarget();
    }

    public void Deactivate()
    {
        active = false;
    }

    void Update()
    {
        if (!active)
            return;

        if (movement == null || wanderArea == null)
            return;

        if (movement.PathPending)
            return;

        if (movement.HasReachedDestination() || movement.IsIdle())
        {
            waitTimer -= Time.deltaTime;

            if (waitTimer <= 0f)
                ChooseNewTarget();

            return;
        }
    }

    void ChooseNewTarget()
    {
        Vector3 randomPos = wanderArea.GetRandomPosition();

        if (
            NavMesh.SamplePosition(
                randomPos,
                out NavMeshHit hit,
                samplePositionRadius,
                NavMesh.AllAreas
            )
        )
        {
            movement.SetDestination(hit.position);
        }

        waitTimer = waitTime;
    }
}
