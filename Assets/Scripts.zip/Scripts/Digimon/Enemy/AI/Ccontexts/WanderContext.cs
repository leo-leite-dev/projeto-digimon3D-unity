public struct WanderContext
{
    public DigimonMovement Movement;
    public IWanderPositionSampler PositionSampler;

    public WanderContext(DigimonMovement movement, IWanderPositionSampler positionSampler)
    {
        Movement = movement;
        PositionSampler = positionSampler;
    }
}
