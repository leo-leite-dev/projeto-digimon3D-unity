using UnityEngine;

public class EnemyAlert : MonoBehaviour, IEnemyBehaviour
{
    private DigimonMovement movement;
    private DigimonEnemyController controller;
    private Transform target;

    [Header("Alert")]
    [SerializeField]
    private float alertDuration = 1.5f;

    private float timer;
    private bool active;

    public void Inject(DigimonMovement movement, DigimonEnemyController controller)
    {
        this.movement = movement;
        this.controller = controller;
    }

    public void SetTarget(Transform target)
    {
        this.target = target;
    }

    public void Activate()
    {
        Debug.Log($"[ALERT] movement:{movement} controller:{controller}");

        if (movement == null || controller == null)
            return;

        active = true;
        timer = alertDuration;

        movement.StopMovement();
    }

    public void Deactivate()
    {
        active = false;
    }

    private void Update()
    {
        if (!active)
            return;

        RotateToTarget();

        timer -= Time.deltaTime;

        if (timer <= 0f)
            FinishAlert();
    }

    private void RotateToTarget()
    {
        if (target == null)
            return;

        movement.RotateToTarget(target);
    }

    private void FinishAlert()
    {
        active = false;

        controller.OnAlertFinished();
    }
}
