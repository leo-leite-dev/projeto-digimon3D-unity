using UnityEngine;

public class EnemyCombat : MonoBehaviour, IEnemyBehaviour
{
    private DigimonMovement movement;
    private EnemyTargeting targeting;
    private Digimon digimon;

    private DigimonSkill currentSkill;

    private CombatDecisionMaker decisionMaker;
    private SkillSelector skillSelector;
    private CombatDecisionExecutor executor;

    private float nextGlobalCastTime;
    private float globalCooldown = 3f;

    private bool active;

    private CombatDecision currentDecision;
    private bool isExecuting;

    public void Inject(
        DigimonMovement movement,
        EnemyTargeting targeting,
        DigimonAttack attack,
        Digimon digimon
    )
    {
        if (movement == null || targeting == null || attack == null || digimon == null)
            return;

        this.movement = movement;
        this.targeting = targeting;
        this.digimon = digimon;

        decisionMaker = new CombatDecisionMaker(attack);
        skillSelector = new SkillSelector();
        executor = new CombatDecisionExecutor(movement, attack);
    }

    public void Activate()
    {
        if (movement == null || targeting == null || digimon == null)
            return;

        active = true;
        currentSkill = null;
        isExecuting = false;
    }

    public void Deactivate()
    {
        active = false;
        currentSkill = null;
        isExecuting = false;
    }

    private void Update()
    {
        if (!CanUpdate())
            return;

        TickCombat();
    }

    private void TickCombat()
    {
        if (!CanCast())
            return;

        var context = BuildContext();
        if (!context.HasValue)
            return;

        EnsureSkillSelected();
        if (currentSkill == null)
            return;

        if (isExecuting)
        {
            executor.Execute(currentDecision, transform);
            return;
        }

        currentDecision = decisionMaker.Decide(currentSkill, context.Value);

        if (currentDecision.Action == CombatAction.UseSkill)
            isExecuting = true;

        executor.Execute(currentDecision, transform);

        HandlePostDecision(currentDecision);
    }

    private bool CanUpdate()
    {
        return active && decisionMaker != null && skillSelector != null;
    }

    private bool CanCast()
    {
        return Time.time >= nextGlobalCastTime;
    }

    private CombatContext? BuildContext()
    {
        var target = targeting.CurrentTarget;

        if (target == null)
            return null;

        Vector3 origin = transform.position;
        Vector3 direction = (target.position - origin).normalized;

        return new CombatContext(origin, direction, target.gameObject);
    }

    private void EnsureSkillSelected()
    {
        if (currentSkill != null)
            return;

        currentSkill = skillSelector.Select(digimon);
    }

    private void HandlePostDecision(CombatDecision decision)
    {
        if (decision.Action != CombatAction.UseSkill)
            return;

        nextGlobalCastTime = Time.time + globalCooldown;
    }

    public void OnSkillFinished()
    {
        isExecuting = false;
        currentSkill = null;
    }
}
