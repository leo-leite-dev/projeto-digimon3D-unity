using UnityEngine;

public class EnemyWander : MonoBehaviour, IEnemyBehaviour, IContextInitializable<WanderContext>
{
    private DigimonMovement movement;
    private IWanderPositionSampler positionSampler;

    [Header("Wander")]
    [SerializeField]
    private float waitTime = 2f;

    private float waitTimer;
    private bool active;

    public void Initialize(WanderContext context)
    {
        if (context.Movement == null || context.PositionSampler == null)
            return;

        movement = context.Movement;
        positionSampler = context.PositionSampler;

        active = false;
    }

    public void Activate()
    {
        if (movement == null)
            return;

        active = true;
        waitTimer = waitTime;

        ChooseNewTarget();
    }

    public void Deactivate()
    {
        active = false;
        // movement?.StopMovement();
    }

    void Update()
    {
        if (!active)
            return;

        if (movement.PathPending)
            return;

        if (IsIdle())
            ProcessIdleState();
    }

    private bool IsIdle()
    {
        return movement.HasReachedDestination() || movement.IsIdle();
    }

    private void ProcessIdleState()
    {
        waitTimer -= Time.deltaTime;

        if (waitTimer <= 0f)
            ChooseNewTarget();
    }

    private void ChooseNewTarget()
    {
        Vector3 validPos = positionSampler.Sample();

        RequestMoveTo(validPos);

        waitTimer = waitTime;
    }

    private void RequestMoveTo(Vector3 destination)
    {
        movement.SetDestination(destination);
    }
}
