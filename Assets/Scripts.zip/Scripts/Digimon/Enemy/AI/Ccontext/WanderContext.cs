public struct WanderContext
{
    public WanderArea WanderArea;
    public DigimonMovement Movement;
    public DigimonAnimator Animator;

    public WanderContext(WanderArea wanderArea, DigimonMovement movement, DigimonAnimator animator)
    {
        WanderArea = wanderArea;
        Movement = movement;
        Animator = animator;
    }
}
