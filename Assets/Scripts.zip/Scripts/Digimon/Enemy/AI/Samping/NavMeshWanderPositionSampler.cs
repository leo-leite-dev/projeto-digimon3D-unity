using UnityEngine;
using UnityEngine.AI;

public class NavMeshWanderPositionSampler : IWanderPositionSampler
{
    private readonly WanderArea wanderArea;
    private readonly float radius;

    public NavMeshWanderPositionSampler(WanderArea wanderArea, float radius)
    {
        this.wanderArea = wanderArea;
        this.radius = radius;
    }

    public Vector3 Sample()
    {
        Vector3 randomPos = wanderArea.GetRandomPosition();

        if (NavMesh.SamplePosition(randomPos, out NavMeshHit hit, radius, NavMesh.AllAreas))
            return hit.position;

        return randomPos;
    }
}
