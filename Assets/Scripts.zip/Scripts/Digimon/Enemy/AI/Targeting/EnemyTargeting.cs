using System.Collections.Generic;
using UnityEngine;

public class EnemyTargeting
{
    private readonly Dictionary<Transform, float> threatTable = new();

    private Transform currentTarget;
    public Transform CurrentTarget => currentTarget;

    public void NotifyThreat(Transform attacker, float threat = 1f)
    {
        if (attacker == null)
            return;

        AddThreat(attacker, threat);
        RecalculateTarget();
    }

    private void AddThreat(Transform target, float amount)
    {
        if (!threatTable.ContainsKey(target))
            threatTable[target] = 0f;

        threatTable[target] += amount;
    }

    private void RecalculateTarget()
    {
        Transform bestTarget = null;
        float highestThreat = float.MinValue;

        foreach (var pair in threatTable)
        {
            var target = pair.Key;
            var threat = pair.Value;

            if (target == null)
                continue;

            if (threat > highestThreat)
            {
                highestThreat = threat;
                bestTarget = target;
            }
        }

        currentTarget = bestTarget;
    }

    public void RemoveTarget(Transform target)
    {
        if (target == null)
            return;

        if (threatTable.ContainsKey(target))
            threatTable.Remove(target);

        if (currentTarget == target)
            RecalculateTarget();
    }

    public void Clear()
    {
        threatTable.Clear();
        currentTarget = null;
    }
}
