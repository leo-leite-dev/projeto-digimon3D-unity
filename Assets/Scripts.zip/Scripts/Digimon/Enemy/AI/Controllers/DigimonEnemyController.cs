using UnityEngine;

public class DigimonEnemyController : MonoBehaviour
{
    private IEnemyBehaviour wander;
    private IEnemyBehaviour alert;
    private EnemyCombat combat;
    private IEnemyBehaviour currentBehaviour;

    private DigimonMovement movement;
    private EnemyTargeting targeting;
    private Digimon digimon;

    private EnemyState currentState;

    public bool IsInCombat => currentState == EnemyState.InCombat;

    public void Inject(EnemyTargeting targeting, Digimon digimon)
    {
        this.targeting = targeting;
        this.digimon = digimon;
    }

    public void BindHitReceiver(DigimonHitReceiver hitReceiver)
    {
        if (hitReceiver == null)
            return;

        hitReceiver.OnHit -= HandleHit;
        hitReceiver.OnHit += HandleHit;
    }

    private void Awake()
    {
        wander = GetComponent<EnemyWander>();
        alert = GetComponent<EnemyAlert>();
        combat = GetComponent<EnemyCombat>();
        movement = GetComponent<DigimonMovement>();
    }

    private void Start()
    {
        (alert as EnemyAlert)?.Inject(movement, this);

        ChangeState(EnemyState.Patrol, wander);
    }

    private void HandleHit(Transform attacker)
    {
        if (attacker == null || targeting == null)
            return;

        Debug.Log($"🔥 [{name}] HIT RECEBIDO de: {attacker.name}");

        targeting.NotifyThreat(attacker);

        if (!IsInCombat)
            EnterAlertState(attacker);
    }

    private void EnterAlertState(Transform attacker)
    {
        (alert as EnemyAlert)?.SetTarget(attacker);

        ChangeState(EnemyState.Alert, alert);
    }

    public void OnAlertFinished()
    {
        EnterCombat();
    }

    private void EnterCombat()
    {
        if (targeting == null || digimon == null || movement == null || combat == null)
        {
            Debug.LogError($"🚨 [{name}] EnterCombat falhou: dependências inválidas");
            return;
        }

        var attack = GetComponent<DigimonAttack>();

        if (attack == null)
        {
            Debug.LogError($"🚨 [{name}] DigimonAttack não encontrado");
            return;
        }

        combat.Inject(movement, targeting, attack, digimon);

        ChangeState(EnemyState.InCombat, combat);
    }

    public void ExitCombat()
    {
        ChangeState(EnemyState.Patrol, wander);
    }

    private void ChangeState(EnemyState newState, IEnemyBehaviour newBehaviour)
    {
        if (currentState == newState)
            return;

        Debug.Log(
            $"🔄 STATE CHANGE: {currentState} → {newState} | Behaviour: {newBehaviour?.GetType().Name}"
        );

        currentState = newState;
        SwitchTo(newBehaviour);
    }

    private void SwitchTo(IEnemyBehaviour next)
    {
        currentBehaviour?.Deactivate();
        currentBehaviour = next;
        currentBehaviour?.Activate();
    }
}
