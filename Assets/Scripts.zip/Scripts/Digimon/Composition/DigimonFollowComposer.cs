using UnityEngine;

public static class DigimonFollowComposer
{
    public static void Compose(GameObject digimonGO)
    {
        var references = digimonGO.GetComponent<DigimonReferences>();

        if (references == null || !references.HasCoreReferences())
        {
            Debug.LogError("❌ References inválidas", digimonGO);
            return;
        }

        var digimon = references.Digimon;
        var attack = digimonGO.GetComponent<DigimonAttack>();
        var follow = references.Follow;

        if (digimon == null || attack == null || follow == null)
        {
            Debug.LogError("❌ Dependências do Follow incompletas", digimonGO);
            return;
        }

        if (!DigimonVisualComposer.SetupVisual(references, digimonGO, attack))
            return;

        DigimonAttackComposer.Compose(attack, references, references.ProjectilePool);

        var combat = digimonGO.GetComponent<DigimonFollowController>();
        if (combat == null)
            combat = digimonGO.AddComponent<DigimonFollowController>();

        combat.Inject(attack);
        combat.SetAnimator(references.DigimonAnimator);

        var hitReceiver = digimonGO.GetComponentInChildren<DigimonHitReceiver>();

        if (hitReceiver == null)
        {
            Debug.LogError("❌ DigimonHitReceiver não encontrado no Follow", digimonGO);
        }
        else
        {
            hitReceiver.Inject(digimon, references.DigimonAnimator);
            combat.BindHitReceiver(hitReceiver);
        }

        follow.Inject(references, combat);

        BindAnimationEvents(references, attack);

        DigimonVisualComposer.BindMovementAnimator(references, digimonGO);
    }

    private static void BindAnimationEvents(DigimonReferences references, DigimonAttack attack)
    {
        var animator = references.DigimonAnimator;

        if (animator == null)
        {
            Debug.LogError("❌ DigimonAnimator não encontrado para binding");
            return;
        }

        animator.OnSpawnEffect += attack.OnSpawnEffect;
        animator.OnApplyHit += attack.OnApplyHit;
        animator.OnFinishSkill += attack.OnFinishSkill;
    }
}
