using UnityEngine;

public static class DigimonComposer
{
    public static void Compose(GameObject digimonGO)
    {
        var references = digimonGO.GetComponent<DigimonReferences>();

        if (references == null)
        {
            Debug.LogError("❌ DigimonReferences não encontrado");
            return;
        }

        if (!references.HasVisualReferences())
        {
            Debug.LogError("❌ Referências visuais não inicializadas");
            return;
        }

        var digimonAnimator = references.DigimonAnimator;

        if (digimonAnimator == null)
            Debug.LogWarning("⚠️ DigimonAnimator não encontrado");

        // exemplo: bind de attack, animation, etc
        // attack.BindAnimator(digimonAnimator);
    }
}
