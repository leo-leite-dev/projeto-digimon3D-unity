using UnityEngine;

public static class DigimonVisualComposer
{
    public static bool SetupVisual(
        DigimonReferences references,
        GameObject digimonGO,
        DigimonAttack attack
    )
    {
        foreach (Transform child in references.ModelRoot)
            Object.Destroy(child.gameObject);

        var data = references.Digimon.Data;

        if (data == null || data.modelPrefab == null)
        {
            Debug.LogError("❌ DigimonData ou ModelPrefab não definido", digimonGO);
            return false;
        }

        var modelInstance = Object.Instantiate(data.modelPrefab, references.ModelRoot);

        modelInstance.transform.localPosition = Vector3.zero;
        modelInstance.transform.localRotation = Quaternion.identity;
        modelInstance.transform.localScale = Vector3.one;

        var animator = modelInstance.GetComponentInChildren<Animator>();

        if (animator == null)
        {
            Debug.LogError("❌ Animator não encontrado", digimonGO);
            return false;
        }

        var firePoint = FindDeepChild(modelInstance.transform, "FirePoint");

        var digimonAnimator =
            references.ModelRoot.GetComponent<DigimonAnimator>()
            ?? references.ModelRoot.gameObject.AddComponent<DigimonAnimator>();

        digimonAnimator.Inject(animator);

        var proxy =
            animator.GetComponent<DigimonAnimationEventProxy>()
            ?? animator.gameObject.AddComponent<DigimonAnimationEventProxy>();

        proxy.Initialize(attack);

        references.SetVisualReferences(references.ModelRoot, animator, firePoint, digimonAnimator);

        return true;
    }

    public static void BindMovementAnimator(DigimonReferences references, GameObject go)
    {
        var movementAnimator = go.GetComponent<DigimonMovementAnimator>();

        if (movementAnimator != null && references.Movement != null)
            movementAnimator.Inject(references.Movement, references.DigimonAnimator);
    }

    private static Transform FindDeepChild(Transform parent, string name)
    {
        foreach (var child in parent.GetComponentsInChildren<Transform>(true))
        {
            if (child.name == name)
                return child;
        }

        return null;
    }
}
