public class DigimonAttackDependenciesFactory
{
    public DigimonAttackDependencies Create(
        DigimonReferences references,
        SkillHitExecutor hitExecutor,
        ProjectilePool projectilePool
    )
    {
        var cooldownTracker = new SkillCooldownTracker();
        var executionState = new SkillExecutionState();

        var usageValidator = new SkillUsageValidator(cooldownTracker, executionState);

        var castPresentation = new SkillCastPresentation(
            references.Movement,
            references.DigimonAnimator
        );

        var castPipeline = new SkillCastPipeline(castPresentation, cooldownTracker);

        var castOrchestrator = new SkillCastOrchestrator(
            usageValidator,
            executionState,
            castPipeline
        );

        var finishResolver = new SkillFinishResolver(executionState, castOrchestrator);

        var spawner = new SkillEffectSpawner(projectilePool);

        var effectSpawnCoordinator = new SkillEffectSpawnCoordinator(
            spawner,
            finishResolver,
            executionState
        );

        var impactCoordinator = new SkillCoordinator(hitExecutor, executionState);

        return new DigimonAttackDependencies(
            executionState,
            castOrchestrator,
            effectSpawnCoordinator,
            impactCoordinator,
            finishResolver
        );
    }
}
