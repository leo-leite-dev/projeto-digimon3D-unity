using UnityEngine;

public static class DigimonEnemyComposer
{
    public static void Compose(GameObject digimonGO)
    {
        var references = digimonGO.GetComponent<DigimonReferences>();

        if (references == null || !references.HasCoreReferences())
        {
            Debug.LogError("❌ References inválidas", digimonGO);
            return;
        }

        var digimon = references.Digimon;
        var attack = digimonGO.GetComponent<DigimonAttack>();
        var controller = digimonGO.GetComponent<DigimonEnemyController>();
        var combat = digimonGO.GetComponent<EnemyCombat>();

        var targeting = new EnemyTargeting();

        if (digimon == null || attack == null || controller == null || combat == null)
        {
            Debug.LogError("❌ Dependências do Enemy incompletas", digimonGO);
            return;
        }

        if (!DigimonVisualComposer.SetupVisual(references, digimonGO, attack))
            return;

        DigimonAttackComposer.Compose(attack, references, references.ProjectilePool);

        controller.Inject(targeting, digimon);

        combat.Inject(references.Movement, targeting, attack, digimon);

        var enemyView = digimonGO.GetComponent<DigimonEnemyView>();
        if (enemyView != null)
            enemyView.Inject(references.DigimonAnimator);

        var hitReceiver = digimonGO.GetComponentInChildren<DigimonHitReceiver>();

        if (hitReceiver == null)
            Debug.LogError("❌ DigimonHitReceiver não encontrado", digimonGO);
        else
        {
            hitReceiver.Inject(digimon, references.DigimonAnimator);
            controller.BindHitReceiver(hitReceiver);
        }

        DigimonVisualComposer.BindMovementAnimator(references, digimonGO);
    }
}
