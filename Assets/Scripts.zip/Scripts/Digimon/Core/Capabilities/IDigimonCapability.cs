public interface IDigimonCapability { }
